import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Livro from '../../components/Livro';
import { buscaLivros } from '../../services/livro';
import { BotaoCabecalho, Container, ContainerRow, ListagemLivros, NomeUsuario } from './style';

export interface ListaLivrosDTO{
  id: number;
  autor: string;
  imagem: string;
  nome: string;
}
const ListaLivros = () => {
    
  const [
    listaDosLivros,
    setListaDosLivros
  ] = useState([]);

  useEffect(() => {
    const CarregaLivros = async () => {
      const resposta = await buscaLivros();
      const json = await resposta.json();
      console.log('resposta', json)
      setListaDosLivros(json);
    }
    CarregaLivros();
  }, []);
  return (
    <Container>
      <ContainerRow>
          <NomeUsuario>Olá Renato!</NomeUsuario>
          <ContainerRow>
            <BotaoCabecalho>
              <Icon name="heart" size={24} color="#000"/>
            </BotaoCabecalho>
            <BotaoCabecalho>
              <Icon name="search" size={24} color="#000"/>
            </BotaoCabecalho>      
          </ContainerRow>
      </ContainerRow>
      <ListagemLivros
        numColumns={2}
        data={listaDosLivros}
        renderItem={
          ({item}:{item:ListaLivrosDTO}) => <Livro data = {item}/>}
        keyExtractor={(item,index) => 'item' + index}
      />  
    </Container>
  );
};


export default ListaLivros;