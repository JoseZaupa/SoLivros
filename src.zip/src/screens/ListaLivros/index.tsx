import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Livro from '../../components/Livro';
import { BotaoCabecalho, Container, ContainerRow, ListagemLivros, NomeUsuario } from './style';


const ListaLivros = () => {
    
  const [
    listaDosLivros,
    setListaDosLivros
  ] = useState([1,2,3,4]);
  return (
    <Container>
      <ContainerRow>
          <NomeUsuario>Olá Renato!</NomeUsuario>
          <ContainerRow>
            <BotaoCabecalho>
              <Icon name="heart" size={24} color="#000"/>
            </BotaoCabecalho>
            <BotaoCabecalho>
              <Icon name="search" size={24} color="#000"/>
            </BotaoCabecalho>      
          </ContainerRow>
      </ContainerRow>
      <ListagemLivros
        numColumns={2}
        data={listaDosLivros}
        renderItem={item => <Livro />}
        keyExtractor={item => 'item' + item}
      />  
    </Container>
  );
};


export default ListaLivros;