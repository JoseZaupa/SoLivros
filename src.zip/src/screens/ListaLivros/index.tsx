import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Livro from '../../components/Livro';


const ListaLivros = () => {
    
  const [
    listaDosLivros,
    setListaDosLivros
  ] = useState([1,2,3,4]);
  return (
    <View
    style={{
      backgroundColor: '#fff',  
      flex: 1,
      padding: 16
      
    }}
    >
      <View style ={{
        flexDirection: 'row'
      }}>
          <Text style={{
            flex: 1,
            fontSize: 22
          }}>Olá Renato.</Text>
          <View style={{
            flexDirection: 'row'
          }}>
            <TouchableOpacity style ={{
              height: 42,
              width: 42,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Icon name="heart" size={24} color="#000"></Icon>
            </TouchableOpacity>
            <TouchableOpacity style ={{
              height: 42,
              width: 42,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Icon name="search" size={24} color="#000"></Icon>
            </TouchableOpacity>      
          </View>
      </View>
      <FlatList
        numColumns={2}
        style={{ flex:1 }}
        data={listaDosLivros}
        renderItem={item => <Livro />}
        keyExtractor={item => 'item' + item}
      />  
    </View>
  );
};


export default ListaLivros;