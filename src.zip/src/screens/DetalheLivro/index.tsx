import { useNavigation } from '@react-navigation/native';
import { forSlideLeft } from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import { Image, ScrollView, StatusBar, StatusBarIOS, Text, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { block } from 'react-native-reanimated';
import { createIconSetFromFontello } from 'react-native-vector-icons';
import Icon from 'react-native-vector-icons/FontAwesome';
import { AutorLivro, BotaAdicionaFavorito, Container, ContainerDescricao, ContainerLivro, ImagemLivro, TextoBotaoAdiconaFavorito, TextoDescricao, TituloDescricao, TituloLivro } from './style';

const DetalheLivro = () => {
    const navigation = useNavigation();
    return <>
        <StatusBar barStyle ="dark-content" backgroundColor = "#E7F5F8"/>
        <Container>
    <ScrollView>
    <ContainerLivro>
       <View>
           <TouchableOpacity
            onPress ={() => {navigation.goBack();}}>
               <Icon name = "arrow-left" size={24} color={"#000"}/>
           </TouchableOpacity>
           </View> 
           <ImagemLivro                
               resizeMode="contain"
               source = {require('../../assets/202852714dec217e579db202a977be70.jpg')}/>   
            <TituloLivro>Titulo Livro</TituloLivro>   
            <AutorLivro>Autor Livro</AutorLivro>
        </ContainerLivro>  
        <View>
         <ContainerDescricao>
             <TituloDescricao>Descrição</TituloDescricao>
             <TextoDescricao>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam cursus tincidunt eros, dignissim laoreet neque mattis non. Nullam cursus sed nulla in cursus. Maecenas vitae dapibus tortor.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam cursus tincidunt eros, dignissim laoreet neque mattis non. Nullam cursus sed nulla in cursus. Maecenas vitae dapibus tortor.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam cursus tincidunt eros, dignissim laoreet neque mattis non. Nullam cursus sed nulla in cursus. Maecenas vitae dapibus tortor.</TextoDescricao>
         </ContainerDescricao> 
        </View> 
    </ScrollView> 
    <BotaAdicionaFavorito>
               <TextoBotaoAdiconaFavorito>Adicionar aos Favoritos</TextoBotaoAdiconaFavorito>
            </BotaAdicionaFavorito>   
    </Container>
    </>
};

export default DetalheLivro;
