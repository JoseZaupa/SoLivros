import { useNavigation, useRoute } from '@react-navigation/native';
import { forSlideLeft } from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Image, ScrollView, StatusBar, StatusBarIOS, Text, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { block } from 'react-native-reanimated';
import { createIconSetFromFontello } from 'react-native-vector-icons';
import Icon from 'react-native-vector-icons/FontAwesome';
import { buscaDetalheLivro } from '../../services/livro';
import { AutorLivro, BotaAdicionaFavorito, Container, ContainerDescricao, ContainerLivro, ImagemLivro, TextoBotaoAdiconaFavorito, TextoDescricao, TituloDescricao, TituloLivro } from './style';
interface DetalheLivroDTO{
    id: number;
    nome: string;
    autor: string;
    imagem: string;
    descricao: string;
}
const DetalheLivro = () => {
    const navigation = useNavigation();
    const route = useRoute();

    const livroid = route.params.livroId;
    console.log('livroId',livroid)
    
    const [detalhelivro, setdetalhelivro] = useState<DetalheLivroDTO|null>(null);
        
    useEffect(() => {
       const CarregaDetalheLivro = async() => {
        const livroid = route.params.livroId;
        console.log('livroId',livroid);
        const resposta = await buscaDetalheLivro(livroid);
        const json = await resposta.json();
        console.log(buscaDetalheLivro, )
        setdetalhelivro(json);
        };
        CarregaDetalheLivro();
    },[]);
    if(detalhelivro === null){
        return <View style ={{flex: 1}}>
            <ActivityIndicator size={42} color = "#023E8A"/>
        </View>
    } 
    return <>
        <StatusBar barStyle ="dark-content" backgroundColor = "#E7F5F8"/>
        <Container>
    <ScrollView>
    <ContainerLivro>
       <View>
           <TouchableOpacity
            onPress ={() => {navigation.goBack();}}>
               <Icon name = "arrow-left" size={24} color={"#000"}/>
           </TouchableOpacity>
           </View> 
           <ImagemLivro                
               resizeMode="contain"
               source = {{uri: detalhelivro.imagem}}/>   
            <TituloLivro>{detalhelivro.nome}</TituloLivro>   
            <AutorLivro>{detalhelivro.autor}</AutorLivro>
        </ContainerLivro>  
        <View>
         <ContainerDescricao>
             <TituloDescricao>Descrição</TituloDescricao>
             <TextoDescricao>{detalhelivro.descricao}</TextoDescricao>
         </ContainerDescricao> 
        </View> 
    </ScrollView> 
    <BotaAdicionaFavorito>
               <TextoBotaoAdiconaFavorito>Adicionar aos Favoritos</TextoBotaoAdiconaFavorito>
            </BotaAdicionaFavorito>   
    </Container>
    </>
};

export default DetalheLivro;
