import React from 'react';

const DetalheLivro = () => {
    return <></>
};

export default DetalheLivro;
