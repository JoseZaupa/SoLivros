import styled from 'styled-components/native'

export const Container = styled.View`
     background-color: #FFF;
     flex: 1;
`;

export const ContainerLivro = styled.View`
    background-color: #E7F5F8;
    padding: 16px;
`;

export const ImagemLivro = styled.Image`
    height: 256px; 
    width: 100%; 
    margin-top: 24px;
`;

export const TituloLivro = styled.Text`
    text-align: center;
    font-size: 24px;
    margin-top: 16px;
    font-weight: bold;
`;

export const AutorLivro = styled.Text`
    text-align: center;
    font-size: 18px;
    color: #AAA;
`;

export const ContainerDescricao = styled.View`
    padding:16px;
    margin-top: 8px;
`;

export const TituloDescricao = styled.Text`
    font-weight: bold;
    font-size: 16px;
`;

export const TextoDescricao = styled.Text`
    color: #AAA;
    font-size: 16px;
`;

export const BotaAdicionaFavorito = styled.TouchableOpacity`
    height: 56px;
    align-items: center;
    justify-content: center;
    background-color: #023E8A;
    border-radius: 8px;
    margin: 16px;
`;

export const TextoBotaoAdiconaFavorito = styled.Text`
    color: #FFF;
    font-size: 16px;
    font-weight: bold;
`;