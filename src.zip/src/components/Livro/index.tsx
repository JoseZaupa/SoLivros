import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  FlatList,Image
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { ContainerBotao, LivroImagem, NomeAutor, NomeLivro } from './style';
const Livro = () => {
    const navigation = useNavigation();
    return <ContainerBotao
        onPress = {() => {
            navigation.navigate('DetalheLivro');
        }}>
            <LivroImagem 
                resizeMode="contain"
                source = {require('../../assets/202852714dec217e579db202a977be70.jpg')}/>   
                <NomeLivro>Nome do Livro</NomeLivro>    
                <NomeAutor>Nome do Autor</NomeAutor>

    </ContainerBotao>
};

export default Livro;