import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  FlatList,Image
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
const Livro = () => {
    const navigation = useNavigation();
    return <TouchableOpacity 
    onPress = {() => {
        navigation.navigate('DetalheLivro');
    }}
    style ={{
        flex: 1,
        margin: 8
    }}>
     <Image 
     style = {{
         height: 256, width: '100%'
     }}
     resizeMode="contain"
     source = {require('../../assets/202852714dec217e579db202a977be70.jpg')}/>   
     <Text style ={{
         fontWeight: 'bold',
         fontSize: 18
     }}>Nome do Livro</Text>    
     <Text style ={{
         fontSize: 14,
         color: '#AAA'
     }}>Nome do Autor</Text>

    </TouchableOpacity>
};

export default Livro;