import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  FlatList,Image
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { ListaLivrosDTO } from '../../screens/ListaLivros';
import { ContainerBotao, LivroImagem, NomeAutor, NomeLivro } from './style';
interface LivroProps {
  data: ListaLivrosDTO
}
const Livro = (props: LivroProps) => {
    const navigation = useNavigation();
    return <ContainerBotao
        onPress = {() => {
            navigation.navigate('DetalheLivro', {
              livroId: props.data.id,
            });
        }}>
            <LivroImagem 
                resizeMode="contain"
                source = {{uri: props.data.imagem}}/>   
                <NomeLivro>{props.data.nome}</NomeLivro>    
                <NomeAutor>{props.data.autor}</NomeAutor>

    </ContainerBotao>
};

export default Livro;